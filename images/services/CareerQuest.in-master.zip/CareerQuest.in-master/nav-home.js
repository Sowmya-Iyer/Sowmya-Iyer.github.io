$(document).ready(function() {

  // SideNav Initialization
  $(".button-collapse").sideNav();
  new WOW().init();
})
